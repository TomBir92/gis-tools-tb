# Atlas Danych — wersja 0.2.21

Wtyczka zawiera wbudowane definicje grup warstw oraz pełny projekt QGIS.

## Zawartość `definitions`

```text
administracja.qlr
fop.qlr
podklady.qlr
ATLAS_DANYCH.qgz
```

## Funkcje

- import jednej lub wielu grup warstw do bieżącego projektu QGIS,
- przyciski **Zaznacz wszystko** i **Odznacz wszystko**,
- ostrzeżenie przed ponownym dodaniem grupy o tej samej nazwie,
- otwarcie pełnego projektu `ATLAS_DANYCH.qgz`.

## Bezpieczeństwo

Pakiet zawiera pliki QLR z zapisanymi danymi dostępowymi. Nie publikuj tej wersji w publicznym repozytorium ani nie przekazuj jej poza zaufane środowisko.


## Zmiana w 0.2.3

- usunięto techniczny komunikat o liczbie znalezionych plików QLR i projekcie QGZ.


## Zmiana w 0.2.4

- dodano pasek postępu podczas wczytywania kilku grup warstw,
- użytkownik widzi aktualnie ładowaną kategorię i może anulować import przed kolejną kategorią,
- dodano wskaźnik pracy podczas otwierania pełnego projektu.


## Zmiana w 0.2.5

- dodano panel **Opis i zawartość kategorii**,
- po kliknięciu kategorii wyświetlany jest jej opis,
- wtyczka odczytuje lokalnie z pliku QLR listę zapisanych grup i warstw,
- podgląd nie ładuje warstw do projektu i nie łączy się z bazą danych.


## Zmiana w 0.2.6

- po uruchomieniu okno otwiera się domyślnie w większym rozmiarze `1000 × 820 px`,
- ustawiono minimalny rozmiar `900 × 680 px`, aby podgląd kategorii pozostał czytelny.


## Zmiana w 0.2.7

- zmieniono opis kategorii **PODKŁADY** zgodnie z aktualnym zakresem warstw.


## Zmiana w 0.2.8

- zmieniono opis kategorii **FOP**.


## Zmiana w 0.2.9

- usunięto tekstowe opisy kategorii,
- zmieniono nagłówek panelu na **Zawartość kategorii**,
- zmieniono etykietę listy na **Dostępne kategorie:**.


## Zmiana w 0.2.10

- usunięto napis **„Warstwy i grupy w definicji:”**,
- nagłówek zmieniono na **„Zawartość kategorii:”**,
- zmniejszono domyślny rozmiar okna do `920 × 720 px`,
- zmniejszono minimalny rozmiar okna do `820 × 620 px`.


## Zmiana w 0.2.11

Lista kategorii jest teraz sterowana przez plik:

```text
atlas_danych/definitions/categories.json
```

Możesz samodzielnie zmieniać:
- nazwy kategorii widoczne w wtyczce,
- kolejność kategorii,
- przypisanie kategorii do pliku `.qlr`,
- dodawać nowe kategorie.

Po edycji `categories.json` zamknij i uruchom okno wtyczki ponownie.


## Zmiana w 0.2.12

- podmieniono pliki `administracja.qlr`, `fop.qlr` i `podklady.qlr` na nowe wersje przekazane do publikacji,
- zachowano `ATLAS_DANYCH.qgz`, `categories.json` oraz wszystkie funkcje wtyczki.


## Zmiana w 0.2.13

- podmieniono plik `ATLAS_DANYCH.qgz` na nową wersję przekazaną do publikacji,
- zachowano aktualne pliki QLR bez parametrów `password=`.


## Zmiana w 0.2.15

- `categories.json` jest teraz odczytywany jako `utf-8-sig`, więc działa zarówno dla plików **UTF-8**, jak i **UTF-8 with BOM**;
- przy błędzie w pliku `categories.json` wtyczka wyświetla ostrzeżenie w panelu komunikatów QGIS, zamiast po cichu używać listy awaryjnej;
- zaktualizowano domyślne nazwy kategorii:
  - GRANICE ADMINISTRACYJNE,
  - FORMY OCHRONY PRZYRODY,
  - MAPY PODKŁADOWE.


## Zmiana w 0.2.17

- przyciski **Zaznacz wszystko** i **Odznacz wszystko** zostały przeniesione pod listę kategorii, do lewego dolnego obszaru okna;
- opis trybu importu zmieniono na **„Importuj wybrane kategorie do bieżącego projektu”**.


## Zmiana w 0.2.18

- zwiększono wcięcia kolejnych poziomów grup i warstw w panelu **Zawartość kategorii**,
- podgrupy są teraz wyraźniej przesunięte w prawo, dzięki czemu hierarchia jest bardziej czytelna.


## Zmiana w 0.2.19

- dodano nową ikonę **Atlas Danych GIS** — atlas, mapa Polski i znacznik lokalizacji,
- ikona jest widoczna w Menedżerze wtyczek oraz na przycisku w pasku narzędzi QGIS.


## Zmiana w 0.2.20

- podmieniono ikonę wtyczki na wersję z nietoperzem na mapie.


## Zmiana w 0.2.21

- podmieniono ikonę również w pliku `icon.svg`, używanym przez Menedżera wtyczek QGIS,
- `metadata.txt` wskazuje teraz na `icon.svg`,
- przycisk w pasku narzędzi również używa tej samej ikony.
