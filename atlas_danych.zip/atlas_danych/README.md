# Atlas Danych — wersja 0.2.13

Wtyczka zawiera wbudowane definicje grup warstw oraz pełny projekt QGIS.

## Zawartość `definitions`

```text
administracja.qlr
fop.qlr
podklady.qlr
ATLAS_DANYCH.qgz
```

## Funkcje

- import jednej lub wielu grup warstw do bieżącego projektu QGIS,
- przyciski **Zaznacz wszystko** i **Odznacz wszystko**,
- ostrzeżenie przed ponownym dodaniem grupy o tej samej nazwie,
- otwarcie pełnego projektu `ATLAS_DANYCH.qgz`.

## Bezpieczeństwo

Pakiet zawiera pliki QLR z zapisanymi danymi dostępowymi. Nie publikuj tej wersji w publicznym repozytorium ani nie przekazuj jej poza zaufane środowisko.


## Zmiana w 0.2.3

- usunięto techniczny komunikat o liczbie znalezionych plików QLR i projekcie QGZ.


## Zmiana w 0.2.4

- dodano pasek postępu podczas wczytywania kilku grup warstw,
- użytkownik widzi aktualnie ładowaną kategorię i może anulować import przed kolejną kategorią,
- dodano wskaźnik pracy podczas otwierania pełnego projektu.


## Zmiana w 0.2.5

- dodano panel **Opis i zawartość kategorii**,
- po kliknięciu kategorii wyświetlany jest jej opis,
- wtyczka odczytuje lokalnie z pliku QLR listę zapisanych grup i warstw,
- podgląd nie ładuje warstw do projektu i nie łączy się z bazą danych.


## Zmiana w 0.2.6

- po uruchomieniu okno otwiera się domyślnie w większym rozmiarze `1000 × 820 px`,
- ustawiono minimalny rozmiar `900 × 680 px`, aby podgląd kategorii pozostał czytelny.


## Zmiana w 0.2.7

- zmieniono opis kategorii **PODKŁADY** zgodnie z aktualnym zakresem warstw.


## Zmiana w 0.2.8

- zmieniono opis kategorii **FOP**.


## Zmiana w 0.2.9

- usunięto tekstowe opisy kategorii,
- zmieniono nagłówek panelu na **Zawartość kategorii**,
- zmieniono etykietę listy na **Dostępne kategorie:**.


## Zmiana w 0.2.10

- usunięto napis **„Warstwy i grupy w definicji:”**,
- nagłówek zmieniono na **„Zawartość kategorii:”**,
- zmniejszono domyślny rozmiar okna do `920 × 720 px`,
- zmniejszono minimalny rozmiar okna do `820 × 620 px`.


## Zmiana w 0.2.11

Lista kategorii jest teraz sterowana przez plik:

```text
atlas_danych/definitions/categories.json
```

Możesz samodzielnie zmieniać:
- nazwy kategorii widoczne w wtyczce,
- kolejność kategorii,
- przypisanie kategorii do pliku `.qlr`,
- dodawać nowe kategorie.

Po edycji `categories.json` zamknij i uruchom okno wtyczki ponownie.


## Zmiana w 0.2.12

- podmieniono pliki `administracja.qlr`, `fop.qlr` i `podklady.qlr` na nowe wersje przekazane do publikacji,
- zachowano `ATLAS_DANYCH.qgz`, `categories.json` oraz wszystkie funkcje wtyczki.


## Zmiana w 0.2.13

- podmieniono plik `ATLAS_DANYCH.qgz` na nową wersję przekazaną do publikacji,
- zachowano aktualne pliki QLR bez parametrów `password=`.
