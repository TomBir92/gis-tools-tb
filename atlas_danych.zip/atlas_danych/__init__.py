# -*- coding: utf-8 -*-

def classFactory(iface):
    from .atlas_danych import AtlasDanychPlugin
    return AtlasDanychPlugin(iface)
