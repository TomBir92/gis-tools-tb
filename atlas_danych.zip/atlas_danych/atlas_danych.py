# -*- coding: utf-8 -*-
"""
Atlas Danych 0.2.2

Wtyczka korzysta z plików umieszczonych bezpośrednio w katalogu:
    atlas_danych/definitions/

Wymagane pliki:
    administracja.qlr
    fop.qlr
    podklady.qlr
    ATLAS_DANYCH.qgz
"""

import os
import json
import xml.etree.ElementTree as ET

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (
    QAction,
    QButtonGroup,
    QDialog,
    QDialogButtonBox,
    QGroupBox,
    QProgressDialog,
    QApplication,
    QHBoxLayout,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QMessageBox,
    QPushButton,
    QRadioButton,
    QSplitter,
    QVBoxLayout,
    QWidget,
)
from qgis.core import QgsLayerDefinition, QgsProject, Qgis

PLUGIN_NAME = "Atlas Danych GIS"

CATEGORIES_FILE = "categories.json"

# Konfiguracja awaryjna — używana wyłącznie gdy plik categories.json
# zostanie usunięty albo będzie miał błędny format.
DEFAULT_CATEGORIES = [
    {"name": "GRANICE ADMINISTRACYJNE", "file": "administracja.qlr"},
    {"name": "FORMY OCHRONY PRZYRODY", "file": "fop.qlr"},
    {"name": "MAPY PODKŁADOWE", "file": "podklady.qlr"},
]


PROJECT_FILE = "ATLAS_DANYCH.qgz"


class AtlasDanychPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.action = None

    def initGui(self):
        self.action = QAction("Atlas Danych GIS", self.iface.mainWindow())
        self.action.setObjectName("AtlasDanychAction")
        self.action.triggered.connect(self.run)
        self.iface.addPluginToMenu("&Atlas Danych GIS", self.action)
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        if self.action is not None:
            self.iface.removePluginMenu("&Atlas Danych GIS", self.action)
            self.iface.removeToolBarIcon(self.action)

    def run(self):
        dialog = AtlasDanychDialog(self.iface)
        dialog.exec_()


class AtlasDanychDialog(QDialog):
    def __init__(self, iface):
        super().__init__(iface.mainWindow())
        self.iface = iface
        self.definitions_dir = os.path.join(
            os.path.dirname(os.path.abspath(__file__)), "definitions"
        )
        self.category_config_error = ""
        self.categories = self._load_categories()

        self.setWindowTitle("Atlas Danych GIS")

        # Domyślny rozmiar zapewniający czytelny podgląd, ale bez nadmiernego zajmowania ekranu.
        self.resize(920, 720)
        self.setMinimumSize(820, 620)

        self._build_ui()
        self._update_mode()

        if self.category_config_error:
            self.iface.messageBar().pushWarning(
                "Atlas Danych GIS",
                "Nie udało się odczytać categories.json. Wczytano listę awaryjną. "
                f"Szczegóły: {self.category_config_error}",
            )

    def _build_ui(self):
        layout = QVBoxLayout(self)

        intro = QLabel(
            "<b>Wczytaj wybrane kategorie warstw do bieżącego projektu QGIS "
            "albo otwórz pełny projekt Atlas Danych GIS.</b>"
        )
        intro.setWordWrap(True)
        layout.addWidget(intro)

        mode_box = QGroupBox("Tryb działania")
        mode_layout = QVBoxLayout(mode_box)

        self.import_radio = QRadioButton(
            "Importuj wybrane kategorie do bieżącego projektu"
        )
        self.open_project_radio = QRadioButton(
            "Otwórz pełny projekt Atlas Danych GIS"
        )
        self.import_radio.setChecked(True)

        self.mode_group = QButtonGroup(self)
        self.mode_group.addButton(self.import_radio)
        self.mode_group.addButton(self.open_project_radio)

        self.import_radio.toggled.connect(self._update_mode)
        self.open_project_radio.toggled.connect(self._update_mode)

        mode_layout.addWidget(self.import_radio)
        mode_layout.addWidget(self.open_project_radio)
        layout.addWidget(mode_box)

        layout.addWidget(QLabel("Dostępne kategorie:"))

        content_splitter = QSplitter(Qt.Horizontal)

        left_container = QWidget()
        left_layout = QVBoxLayout(left_container)
        left_layout.setContentsMargins(0, 0, 0, 0)

        self.category_list = QListWidget()
        self.category_list.setMinimumWidth(230)
        for category_data in self.categories:
            display_name = category_data["name"]
            item = QListWidgetItem(display_name)
            item.setData(Qt.UserRole, category_data["file"])
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
            item.setCheckState(Qt.Unchecked)
            self.category_list.addItem(item)

        self.category_list.currentItemChanged.connect(self.update_category_preview)
        left_layout.addWidget(self.category_list, 1)

        category_actions = QHBoxLayout()
        category_actions.setContentsMargins(0, 0, 0, 0)

        self.select_all_button = QPushButton("Zaznacz wszystko")
        self.select_all_button.clicked.connect(self.select_all)
        self.clear_all_button = QPushButton("Odznacz wszystko")
        self.clear_all_button.clicked.connect(self.clear_all)

        category_actions.addWidget(self.select_all_button)
        category_actions.addWidget(self.clear_all_button)
        category_actions.addStretch()
        left_layout.addLayout(category_actions)

        content_splitter.addWidget(left_container)

        preview_container = QGroupBox("Zawartość kategorii:")
        preview_layout = QVBoxLayout(preview_container)

        self.content_list = QListWidget()
        self.content_list.setSelectionMode(QListWidget.NoSelection)
        preview_layout.addWidget(self.content_list, 1)

        content_splitter.addWidget(preview_container)
        content_splitter.setSizes([360, 560])
        layout.addWidget(content_splitter, 1)

        if self.category_list.count():
            self.category_list.setCurrentRow(0)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.button(QDialogButtonBox.Ok).setText("Wczytaj")
        buttons.accepted.connect(self.execute)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)


    def _load_categories(self):
        """
        Pobiera listę kategorii z definitions/categories.json.
        Nazwy, kolejność i pliki QLR można edytować bez zmiany kodu wtyczki.
        """
        config_path = os.path.join(self.definitions_dir, CATEGORIES_FILE)

        try:
            with open(config_path, "r", encoding="utf-8-sig") as file:
                config = json.load(file)

            categories = config.get("categories", [])
            if not isinstance(categories, list):
                raise ValueError("Pole 'categories' musi być listą.")

            validated = []
            for entry in categories:
                if not isinstance(entry, dict):
                    continue

                name = str(entry.get("name", "")).strip()
                filename = str(entry.get("file", "")).strip()

                if not name or not filename:
                    continue

                # Nie pozwalamy wyjść poza katalog definitions.
                if os.path.basename(filename) != filename:
                    continue

                validated.append({"name": name, "file": filename})

            if not validated:
                raise ValueError("Brak poprawnych kategorii w pliku JSON.")

            return validated

        except Exception as exc:
            self.category_config_error = str(exc)
            return DEFAULT_CATEGORIES

    def update_category_preview(self, current_item, previous_item=None):
        """Aktualizuje opis oraz listę warstw na podstawie wybranej definicji QLR."""
        self.content_list.clear()

        if current_item is None:
            return

        filename = current_item.data(Qt.UserRole)

        path = os.path.join(self.definitions_dir, filename)
        if not os.path.isfile(path):
            item = QListWidgetItem(f"Nie znaleziono pliku: {filename}")
            item.setFlags(Qt.NoItemFlags)
            self.content_list.addItem(item)
            return

        entries = self._read_qlr_contents(path)
        if not entries:
            item = QListWidgetItem("Nie znaleziono nazw warstw w definicji.")
            item.setFlags(Qt.NoItemFlags)
            self.content_list.addItem(item)
            return

        for label, is_group in entries:
            display = f"▸ {label}" if is_group else f"• {label}"
            item = QListWidgetItem(display)
            item.setToolTip(label)
            item.setFlags(Qt.NoItemFlags)
            self.content_list.addItem(item)

    @staticmethod
    def _read_qlr_contents(qlr_path):
        """
        Odczytuje nazwy grup i warstw z pliku QLR.
        Nie otwiera warstw ani nie łączy się z bazą danych.
        """
        entries = []

        try:
            tree = ET.parse(qlr_path)
            root = tree.getroot()
        except (ET.ParseError, OSError):
            return entries

        def visit(element, depth=0):
            tag = element.tag.split("}")[-1]
            name = element.attrib.get("name", "").strip()

            if tag == "layer-tree-group" and name:
                entries.append((("    " * depth) + name, True))
                for child in element:
                    visit(child, depth + 1)
            elif tag == "layer-tree-layer" and name:
                entries.append((("    " * depth) + name, False))
            else:
                for child in element:
                    visit(child, depth)

        visit(root)
        return entries

    def _update_mode(self):
        import_mode = self.import_radio.isChecked()
        self.category_list.setEnabled(import_mode)
        self.select_all_button.setEnabled(import_mode)
        self.clear_all_button.setEnabled(import_mode)

    def select_all(self):
        for row in range(self.category_list.count()):
            self.category_list.item(row).setCheckState(Qt.Checked)

    def clear_all(self):
        for row in range(self.category_list.count()):
            self.category_list.item(row).setCheckState(Qt.Unchecked)

    def selected_categories(self):
        selections = []
        for row in range(self.category_list.count()):
            item = self.category_list.item(row)
            if item.checkState() == Qt.Checked:
                selections.append((item.text(), item.data(Qt.UserRole)))
        return selections

    def execute(self):
        if self.import_radio.isChecked():
            self.import_selected_groups()
        else:
            self.open_full_project()

    def import_selected_groups(self):
        selections = self.selected_categories()
        if not selections:
            self._warning("Brak wyboru", "Zaznacz co najmniej jedną grupę warstw.")
            return

        project = QgsProject.instance()
        root = project.layerTreeRoot()

        progress = QProgressDialog(
            "Przygotowywanie importu warstw…",
            "Anuluj",
            0,
            len(selections),
            self,
        )
        progress.setWindowTitle("Atlas Danych GIS")
        progress.setWindowModality(Qt.WindowModal)
        progress.setMinimumDuration(0)
        progress.setAutoClose(False)
        progress.setAutoReset(False)
        progress.show()
        QApplication.processEvents()

        loaded = 0
        missing = []
        failed = []
        cancelled = False

        for index, (display_name, filename) in enumerate(selections, start=1):
            if progress.wasCanceled():
                cancelled = True
                break

            progress.setLabelText(
                f"Wczytywanie: {display_name} ({index}/{len(selections)})"
            )
            progress.setValue(index - 1)
            QApplication.processEvents()

            path = os.path.join(self.definitions_dir, filename)

            if not os.path.isfile(path):
                missing.append(filename)
                progress.setValue(index)
                QApplication.processEvents()
                continue

            if self._group_exists(root, display_name):
                answer = QMessageBox.question(
                    self,
                    "Grupa już istnieje",
                    f'Grupa „{display_name}” jest już w bieżącym projekcie.\n'
                    "Czy mimo to wczytać ją ponownie?",
                    QMessageBox.Yes | QMessageBox.No,
                    QMessageBox.No,
                )
                if answer != QMessageBox.Yes:
                    progress.setValue(index)
                    QApplication.processEvents()
                    continue

            try:
                ok = QgsLayerDefinition.loadLayerDefinition(path, project, root)
                if ok:
                    loaded += 1
                else:
                    failed.append(filename)
            except Exception as exc:
                failed.append(f"{filename} ({exc})")

            progress.setValue(index)
            QApplication.processEvents()

        progress.setValue(len(selections))
        progress.close()

        details = []
        if loaded:
            details.append(f"Wczytano grupy warstw: {loaded}.")
        if missing:
            details.append("Brak plików: " + ", ".join(missing) + ".")
        if failed:
            details.append("Nie udało się wczytać: " + ", ".join(failed) + ".")
        if cancelled:
            details.append("Import został anulowany.")

        if loaded:
            self._message("Atlas Danych GIS", " ".join(details), Qgis.Success)
            self.accept()
        else:
            self._warning(
                "Nie wczytano warstw",
                " ".join(details) or "Nie udało się wczytać żadnej grupy.",
            )

    def open_full_project(self):
        project_path = os.path.join(self.definitions_dir, PROJECT_FILE)
        if not os.path.isfile(project_path):
            self._warning("Brak projektu", f"Nie znaleziono pliku:\n{project_path}")
            return

        answer = QMessageBox.question(
            self,
            "Otworzyć pełny projekt?",
            "Bieżący projekt QGIS zostanie zamknięty bez automatycznego zapisu. Kontynuować?",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if answer != QMessageBox.Yes:
            return

        progress = QProgressDialog(
            "Otwieranie pełnego projektu Atlas Danych GIS…",
            None,
            0,
            0,
            self,
        )
        progress.setWindowTitle("Atlas Danych GIS")
        progress.setWindowModality(Qt.WindowModal)
        progress.setMinimumDuration(0)
        progress.show()
        QApplication.processEvents()

        try:
            opened = QgsProject.instance().read(project_path)
        finally:
            progress.close()

        if opened:
            self._message("Atlas Danych GIS", "Pełny projekt został otwarty.", Qgis.Success)
            self.accept()
        else:
            self._warning(
                "Błąd projektu",
                f"QGIS nie mógł otworzyć pliku:\n{project_path}",
            )

    @staticmethod
    def _group_exists(root, group_name):
        return any(group.name() == group_name for group in root.findGroups())

    def _message(self, title, message, level):
        self.iface.messageBar().pushMessage(title, message, level=level, duration=8)

    def _warning(self, title, message):
        QMessageBox.warning(self, title, message)
