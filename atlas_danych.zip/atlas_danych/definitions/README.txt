Pliki QLR oraz konfiguracja kategorii wtyczki.

Aby zmienić nazwę, kolejność lub dodać kategorię, edytuj plik categories.json.
Przykład:
{
  "categories": [
    {"name": "ADMINISTRACJA", "file": "administracja.qlr"}
  ]
}

Po zapisaniu pliku uruchom ponownie okno wtyczki.
